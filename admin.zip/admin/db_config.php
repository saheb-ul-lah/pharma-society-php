<?php
$db_host = 'localhost';         // Replace with your database host
$db_name = 'pharmaceutical_society';     // Replace with your database name
$db_user = 'root';     // Replace with your database username
$db_password = ''; // Replace with your database password
?>
